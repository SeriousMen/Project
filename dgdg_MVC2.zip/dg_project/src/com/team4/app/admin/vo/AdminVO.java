package com.team4.app.admin.vo;

public class AdminVO {
	private String adminId;
	private String adminPw;
	
	public AdminVO() {;}
	
	public final String getAdminId() {
		return adminId;
	}
	public final void setAdminId(String adminId) {
		this.adminId = adminId;
	}
	public final String getAdminPw() {
		return adminPw;
	}
	public final void setAdminPw(String adminPw) {
		this.adminPw = adminPw;
	}
	
	
}
