package com.team4.app.visit.vo;

public class VisitVO {

	private String tDate;
	public VisitVO() {;}
	public String gettDate() {
		return tDate;
	}
	public void settDate(String tDate) {
		this.tDate = tDate;
	}
	
	
	
}
